import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  allowedDevOrigins: [
    "tychistic-ira-stretchiest.ngrok-free.dev",
    "localhost:3000",
  ],
};

export default nextConfig;